# folder path: cd "C:\Users\mabra\OneDrive\Desktop\463 Final Project"
from flask import Flask, render_template, request, redirect, url_for, flash, get_flashed_messages

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'  # For session management and flash messages

# In-memory storage for user information
users = {}

@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check if the username exists in the dictionary
        if username in users and users[username]['password'] == password:
            flash('Login successful!', 'success')
            return redirect(url_for('home'))  # Redirect to home or another page after successful login
        else:
            flash('Login failed. Please check your username and password.', 'error')

    return render_template('login.html', messages=get_flashed_messages())

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check if the username already exists
        if username in users:
            flash('Username already exists. Please choose a different one.', 'error')
        else:
            # Store user information in the dictionary
            users[username] = {'password': password}

            flash('Registration successful! You can now log in.', 'success')
            return redirect(url_for('login'))

    return render_template('register.html', messages=get_flashed_messages())

@app.route('/view_users')
def view_users():
    return render_template('view_users.html', users=users)

if __name__ == '__main__':
    app.run(debug=True)


